import os
import jsonlines
import json
import openai
import pandas as pd
import argparse
from tqdm import tqdm

#os.environ["http_proxy"] = "http://localhost:7890"
#os.environ["https_proxy"] = "http://localhost:7890"

api_key = input('Please input ChatGPT api key: ')
process_json = ['test_strong_full.json', 'train_strong.json', 'val_strong.json']
sentence_num = 5
questions = 'Here is a sentence describing the audio content for you. Please output the dialogue content in one sentence. You can play the dialogue content yourself. You only need to output the dialogue content, without outputting the speaker, speaking scene, and other situations. Please output [num] results and label them with serial numbers: '
speech_labels = set(pd.read_csv('class_labels_indices.csv').iloc[[0, 1, 2, 3, 4, 5, 6, 7]]['display_name'].array.tolist())

questions = questions.replace('[num]', str(sentence_num))
openai.api_key = api_key

def ask(question,direct_return=False):
    answers = list()
    while len(answers) == 0:
        text = str()
        while len(text) == 0:
            completion = openai.ChatCompletion.create(
                model="gpt-3.5-turbo-0301",
                messages=[
                    {"role": "user",
                     "content": question},
                ]
            )
            text = completion.choices[0].message['content']
        print("Question: ", question)
        print("Answer: ", text)
        if direct_return:
            print(text)
            return text
        text = text.split('\n')
        for sentence in text:
            if '.' in sentence and sentence[:sentence.index('.')].isdigit():
                answer = sentence[sentence.index('.') + 1:]
                if len(answer) != 0 and answer[0] == " ":
                    answer = answer[1:]
                if len(answer) != 0 and answer[0] == "\"":
                    answer = answer[1:]
                if len(answer) != 0 and answer[-1] == "\"":
                    answer = answer[:-1]
                answers.append(answer)
        print(answers)
    return answers

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Prompt Generation')
    parser.add_argument('--question', type=str, default=str())
    args = parser.parse_args()

    question = args.question
    if len(question) != 0:
        ask(question, direct_return=True)
    else:
        for input_json_path in process_json:
            if os.path.exists(f'processed_{input_json_path}'):
                new_lines = list()
                new_wavs = list()
                for line in open(f'processed_{input_json_path}', encoding='utf-8').readlines():
                    try:
                        line_dict = json.loads(line)
                        new_lines.append(line_dict)
                        new_wavs.append(line_dict['location'])
                    except:
                        continue
            else:
                new_lines = list()
                new_wavs = list()

            old_lines = list()
            for line in open(input_json_path, encoding='utf-8').readlines():
                line_dict = json.loads(line)
                if line_dict['location'] in new_wavs:
                    continue
                else:
                    old_lines.append(line_dict)

            with jsonlines.open(f'processed_{input_json_path}', "w") as writer:
                for line in new_lines:
                    writer.write(line)

            with jsonlines.open(f'processed_{input_json_path}', "a") as writer:
                for line in tqdm(old_lines):
                    labels = set(line['data_numpy'][0])
                    if len(labels & speech_labels) == 0:
                        line['answer'] = list()
                    else:
                        caption = line['captions']
                        questions_caption = questions + caption
                        answers = ask(questions_caption)
                        line['answer'] = answers
                    writer.write(line)





